﻿namespace CourseLibrary.API.Helpers;

public enum ResorceUriType
{
    NextPage,
    PreviousPage
}