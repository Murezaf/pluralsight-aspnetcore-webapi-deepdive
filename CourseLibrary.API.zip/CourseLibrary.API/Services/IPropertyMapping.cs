﻿namespace CourseLibrary.API.Services;

public class IPropertyMapping
{
}
